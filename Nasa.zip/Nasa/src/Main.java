import java.io.*;
public class Main {


    public static void main(String[] args) {
        String path = args[0];
        Point p = null;

        try {
            File file = new File(path);

            BufferedReader br = new BufferedReader(new FileReader(file));
            String[] lineElements;
            String st = br.readLine();
            if(st != null){
                lineElements = st.split(" ");
                PlateauSpecs.maxX=Integer.valueOf(lineElements[0]);
                PlateauSpecs.maxY=Integer.valueOf(lineElements[1]);
            }

            while ((st = br.readLine()) != null){
               lineElements = st.split(" ");
               if(lineElements.length==3){
                    p = new Point(Integer.valueOf(lineElements[0]),Integer.valueOf(lineElements[1]),lineElements[2].charAt(0));
               }else{
                   getNewPosition(p,st);
                   System.out.println(p);
               }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void getNewPosition(Point p,String command){
        for(int i =0 ;i<command.length();i++){
            switch(command.charAt(i)){
                case PlateauConstants.TURN_LEFT : p.turnLeft(); break;
                case PlateauConstants.TURN_RIGHT : p.turnRight(); break;
                case PlateauConstants.MOVE_FORWARD : p.moveForward(); break;
                default: System.err.println("Command is not valid");
            }
        }
    }


}
