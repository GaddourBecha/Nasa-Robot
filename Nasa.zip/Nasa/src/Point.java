public class Point {
    private int x;
    private int y;
    private char direction;

    public Point(int x, int y, char direction) {
        this.x = x;
        this.y = y;
        this.direction = direction;
    }

    @Override
    public String toString() {
        return  x + " " + y + " " + direction;
    }

    public void turnRight(){
        int index = PlateauSpecs.findIndex(direction);
        if(index==3) {
            index = 0;
        }else{
            index++;
        }
        direction = PlateauSpecs.DIRECTIONS[index];
    }

    public void turnLeft(){
        int index = PlateauSpecs.findIndex(direction);
        if(index==0){
            index = 3;
        }else{
            index--;
        }
        direction = PlateauSpecs.DIRECTIONS[index];
    }

    public void moveForward(){
        switch(direction) {
            case PlateauConstants.NORTH:
                incrementY();
                break;
            case PlateauConstants.EAST:
                incrementX();
                break;
            case PlateauConstants.SOUTH:
                decrementY();
                break;
            case PlateauConstants.WEST:
                decrementX();
                break;
            default:
                System.err.println("Current direction is not valid !!");
        }
    }

    private void incrementX(){
        if(x==PlateauSpecs.maxX){
            x=0;
        }else{
            x++;
        }
    }

    private void decrementX(){
        if(x==0){
            x=PlateauSpecs.maxX;
        }else{
            x--;
        }
    }

    private void incrementY(){
        if(y==PlateauSpecs.maxY){
            y=0;
        }else{
            y++;
        }
    }

    private void decrementY(){
        if(y==0){
            y=PlateauSpecs.maxY;
        }else{
            y--;
        }
    }

}
